﻿using System;
using System.Collections.Generic;

namespace Apishki.Models;

public partial class Reservation
{
    public int IdReservation { get; set; }

    public int ProductId { get; set; }

    public int Quantity { get; set; }

    public string Status { get; set; } = null!;

    public DateTime CreatedAt { get; set; }

    public DateTime? CancelledAt { get; set; }

    public virtual Product Product { get; set; } = null!;
}
