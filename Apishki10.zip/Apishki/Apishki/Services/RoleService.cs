﻿using AutoMapper;
using Apishki.DTOs.Role;
using Apishki.Models;
using Apishki.Repositories;
namespace Apishki.Services;

public class RoleService : IRoleService
{
    private readonly IRoleRepository _repository;
    private readonly IMapper _mapper;

    public RoleService(IRoleRepository repository, IMapper mapper)
    {
        _repository = repository; _mapper = mapper;
    }

    public async Task<(List<RoleDTO>, int)> GetAllAsync(int page, int pageSize)
    {
        var items = await _repository.GetAllAsync(page, pageSize);
        var total = await _repository.CountAsync();
        return (_mapper.Map<List<RoleDTO>>(items), total);
    }

    public async Task<RoleDTO?> GetByIdAsync(int id)
    {
        var r = await _repository.GetByIdAsync(id);
        return r is null ? null : _mapper.Map<RoleDTO>(r);
    }

    public async Task<RoleDTO> CreateAsync(CreateRoleDTO dto)
    {
        var r = _mapper.Map<Role>(dto);
        await _repository.AddAsync(r);
        await _repository.SaveChangesAsync();
        return _mapper.Map<RoleDTO>(r);
    }

    public async Task<RoleDTO?> UpdateAsync(int id, UpdateRoleDTO dto)
    {
        var r = await _repository.GetByIdAsync(id);
        if (r is null) return null;
        _mapper.Map(dto, r);
        _repository.Update(r);
        await _repository.SaveChangesAsync();
        return _mapper.Map<RoleDTO>(r);
    }

    public async Task<RoleDTO?> PatchAsync(int id, PatchRoleDTO dto)
    {
        var r = await _repository.GetByIdAsync(id);
        if (r is null) return null;
        if (dto.Title is not null) r.Title = dto.Title;
        _repository.Update(r);
        await _repository.SaveChangesAsync();
        return _mapper.Map<RoleDTO>(r);
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var r = await _repository.GetByIdAsync(id);
        if (r is null) return false;
        _repository.Remove(r);
        await _repository.SaveChangesAsync();
        return true;
    }
}