﻿using Apishki.DTOs.Reservation;

namespace Apishki.Services;

public interface IReservationService
{
    Task<(List<ReservationReadDto> Items, int Total)> GetAllAsync(int page, int pageSize);
    Task<ReservationReadDto?> GetByIdAsync(int id);

    Task<ReservationReadDto> ReserveAsync(CreateReservationDto dto);

    Task<bool> CancelAsync(int id);
}