﻿using AutoMapper;
using Apishki.DTOs.Order;
using Apishki.Models;
using Apishki.Repositories;
namespace Apishki.Services;

public class OrderService : IOrderService
{
    private readonly IOrderRepository _repository;
    private readonly IUserRepository _userRepo;
    private readonly IMapper _mapper;

    public OrderService(IOrderRepository repository, IUserRepository userRepo, IMapper mapper)
    {
        _repository = repository; _userRepo = userRepo; _mapper = mapper;
    }

    public async Task<(List<OrderDTO>, int)> GetAllAsync(int page, int pageSize)
    {
        var items = await _repository.GetAllAsync(page, pageSize);
        var total = await _repository.CountAsync();
        return (_mapper.Map<List<OrderDTO>>(items), total);
    }

    public async Task<OrderDTO?> GetByIdAsync(int id)
    {
        var o = await _repository.GetByIdAsync(id);
        return o is null ? null : _mapper.Map<OrderDTO>(o);
    }

    public async Task<OrderDTO> CreateAsync(CreateOrderDTO dto)
    {
        _ = await _userRepo.GetByIdAsync(dto.UuserId)
            ?? throw new KeyNotFoundException($"Пользователь с id={dto.UuserId} не найден");

        var order = _mapper.Map<Order>(dto);
        order.OrderDate = DateTime.UtcNow;

        await _repository.AddAsync(order);
        await _repository.SaveChangesAsync();

        var saved = await _repository.GetByIdAsync(order.IdOrder);
        return _mapper.Map<OrderDTO>(saved!);
    }

    public async Task<OrderDTO?> UpdateAsync(int id, UpdateOrderDTO dto)
    {
        var o = await _repository.GetByIdAsync(id);
        if (o is null) return null;
        _mapper.Map(dto, o);
        _repository.Update(o);
        await _repository.SaveChangesAsync();
        return _mapper.Map<OrderDTO>(o);
    }

    public async Task<OrderDTO?> PatchAsync(int id, PatchOrderDTO dto)
    {
        var o = await _repository.GetByIdAsync(id);
        if (o is null) return null;

        if (dto.UuserId is not null) o.UuserId = dto.UuserId.Value;
        if (dto.Totalamount is not null) o.Totalamount = dto.Totalamount.Value;
        if (dto.StatusOrder is not null) o.StatusOrder = dto.StatusOrder;
        if (dto.DeliveryAddress is not null) o.DeliveryAddress = dto.DeliveryAddress;

        _repository.Update(o);
        await _repository.SaveChangesAsync();
        return _mapper.Map<OrderDTO>(o);
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var o = await _repository.GetByIdAsync(id);
        if (o is null) return false;
        _repository.Remove(o);
        await _repository.SaveChangesAsync();
        return true;
    }
}