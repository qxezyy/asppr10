﻿using AutoMapper;
using Apishki.DTOs.Product;
using Apishki.Models;
using Apishki.Repositories;

namespace Apishki.Services;

public class ProductService : IProductService
{
    private readonly IProductRepository _repository;
    private readonly IMapper _mapper;

    public ProductService(IProductRepository repository, IMapper mapper)
    {
        _repository = repository;
        _mapper = mapper;
    }

    public async Task<(List<ProductReadDto>, int)> GetAllAsync(int page, int pageSize)
    {
        var items = await _repository.GetAllAsync(page, pageSize);
        var total = await _repository.CountAsync();
        return (_mapper.Map<List<ProductReadDto>>(items), total);
    }

    public async Task<ProductReadDto?> GetByIdAsync(int id)
    {
        var p = await _repository.GetByIdAsync(id);
        return p is null ? null : _mapper.Map<ProductReadDto>(p);
    }

    public async Task<ProductReadDto> CreateAsync(CreateProductDto dto)
    {
        var product = _mapper.Map<Product>(dto);
        product.RegistrationDate = DateTime.UtcNow;

        await _repository.AddAsync(product);
        await _repository.SaveChangesAsync();

        var saved = await _repository.GetByIdAsync(product.IdProduct);
        return _mapper.Map<ProductReadDto>(saved!);
    }

    public async Task<ProductReadDto?> UpdateAsync(int id, UpdateProductDto dto)
    {
        var product = await _repository.GetByIdAsync(id);
        if (product is null) return null;

        _mapper.Map(dto, product); 
        _repository.Update(product);
        await _repository.SaveChangesAsync();

        return _mapper.Map<ProductReadDto>(product);
    }

    public async Task<ProductReadDto?> PatchAsync(int id, PatchProductDto dto)
    {
        var product = await _repository.GetByIdAsync(id);
        if (product is null) return null;

        if (dto.Title is not null) product.Title = dto.Title;
        if (dto.Price is not null) product.Price = dto.Price.Value;
        if (dto.CategoryId is not null) product.CategoryId = dto.CategoryId.Value;
        if (dto.Description is not null) product.DescriptionProduct = dto.Description;
        if (dto.Image is not null) product.Image = dto.Image;
        if (dto.Stock is not null) product.Stock = dto.Stock.Value;

        _repository.Update(product);
        await _repository.SaveChangesAsync();

        return _mapper.Map<ProductReadDto>(product);
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var product = await _repository.GetByIdAsync(id);
        if (product is null) return false;

        _repository.Remove(product);
        await _repository.SaveChangesAsync();
        return true;
    }
}