﻿using Apishki.DTOs.Role;
namespace Apishki.Services;

public interface IRoleService
{
    Task<(List<RoleDTO> Items, int Total)> GetAllAsync(int page, int pageSize);
    Task<RoleDTO?> GetByIdAsync(int id);
    Task<RoleDTO> CreateAsync(CreateRoleDTO dto);
    Task<RoleDTO?> UpdateAsync(int id, UpdateRoleDTO dto);
    Task<RoleDTO?> PatchAsync(int id, PatchRoleDTO dto);
    Task<bool> DeleteAsync(int id);
}