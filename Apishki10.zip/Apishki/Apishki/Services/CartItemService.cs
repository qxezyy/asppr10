﻿using AutoMapper;
using Apishki.DTOs.CartItem;
using Apishki.Models;
using Apishki.Repositories;
namespace Apishki.Services;

public class CartItemService : ICartItemService
{
    private readonly ICartItemRepository _repository;
    private readonly ICartRepository _cartRepo;
    private readonly IProductRepository _productRepo;
    private readonly IMapper _mapper;

    public CartItemService(ICartItemRepository repository, ICartRepository cartRepo,
        IProductRepository productRepo, IMapper mapper)
    {
        _repository = repository; _cartRepo = cartRepo;
        _productRepo = productRepo; _mapper = mapper;
    }

    public async Task<(List<CartItemDTO>, int)> GetAllAsync(int page, int pageSize)
    {
        var items = await _repository.GetAllAsync(page, pageSize);
        var total = await _repository.CountAsync();
        return (_mapper.Map<List<CartItemDTO>>(items), total);
    }

    public async Task<CartItemDTO?> GetByIdAsync(int id)
    {
        var ci = await _repository.GetByIdAsync(id);
        return ci is null ? null : _mapper.Map<CartItemDTO>(ci);
    }

    public async Task<CartItemDTO> CreateAsync(CreateCartItemDTO dto)
    {
        if (await _cartRepo.GetByIdAsync(dto.CartId) is null)
            throw new KeyNotFoundException($"Корзина с id={dto.CartId} не найдена");
        if (await _productRepo.GetByIdAsync(dto.ProductId) is null)
            throw new KeyNotFoundException($"Товар с id={dto.ProductId} не найден");

        var ci = _mapper.Map<CartItem>(dto);
        await _repository.AddAsync(ci);
        await _repository.SaveChangesAsync();

        var saved = await _repository.GetByIdAsync(ci.IdCartitem);
        return _mapper.Map<CartItemDTO>(saved!);
    }

    public async Task<CartItemDTO?> UpdateAsync(int id, UpdateCartItemDTO dto)
    {
        var ci = await _repository.GetByIdAsync(id);
        if (ci is null) return null;

        _mapper.Map(dto, ci);
        _repository.Update(ci);
        await _repository.SaveChangesAsync();
        return _mapper.Map<CartItemDTO>(ci);
    }

    public async Task<CartItemDTO?> PatchAsync(int id, PatchCartItemDTO dto)
    {
        var ci = await _repository.GetByIdAsync(id);
        if (ci is null) return null;

        if (dto.CartId is not null) ci.CartId = dto.CartId.Value;
        if (dto.ProductId is not null) ci.ProductId = dto.ProductId.Value;
        if (dto.Quantity is not null) ci.Quantity = dto.Quantity.Value;

        _repository.Update(ci);
        await _repository.SaveChangesAsync();
        return _mapper.Map<CartItemDTO>(ci);
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var ci = await _repository.GetByIdAsync(id);
        if (ci is null) return false;
        _repository.Remove(ci);
        await _repository.SaveChangesAsync();
        return true;
    }
}