﻿using AutoMapper;
using Apishki.DTOs.Cart;
using Apishki.Models;
using Apishki.Repositories;
namespace Apishki.Services;

public class CartService : ICartService
{
    private readonly ICartRepository _repository;
    private readonly IUserRepository _userRepo;
    private readonly IMapper _mapper;

    public CartService(ICartRepository repository, IUserRepository userRepo, IMapper mapper)
    {
        _repository = repository;
        _userRepo = userRepo;
        _mapper = mapper;
    }

    public async Task<(List<CartDTO>, int)> GetAllAsync(int page, int pageSize)
    {
        var items = await _repository.GetAllAsync(page, pageSize);
        var total = await _repository.CountAsync();
        return (_mapper.Map<List<CartDTO>>(items), total);
    }

    public async Task<CartDTO?> GetByIdAsync(int id)
    {
        var c = await _repository.GetByIdAsync(id);
        return c is null ? null : _mapper.Map<CartDTO>(c);
    }

    public async Task<CartDTO> CreateAsync(CreateCartDTO dto)
    {
        _ = await _userRepo.GetByIdAsync(dto.UuserId)
            ?? throw new KeyNotFoundException($"Пользователь с id={dto.UuserId} не найден");

        var cart = _mapper.Map<Cart>(dto);
        cart.CreationDate = DateTime.UtcNow;

        await _repository.AddAsync(cart);
        await _repository.SaveChangesAsync();

        var saved = await _repository.GetByIdAsync(cart.IdCart);
        return _mapper.Map<CartDTO>(saved!);
    }

    public async Task<CartDTO?> UpdateAsync(int id, UpdateCartDTO dto)
    {
        var cart = await _repository.GetByIdAsync(id);
        if (cart is null) return null;

        _mapper.Map(dto, cart);
        cart.UpdateDate = DateTime.UtcNow;

        _repository.Update(cart);
        await _repository.SaveChangesAsync();
        return _mapper.Map<CartDTO>(cart);
    }

    public async Task<CartDTO?> PatchAsync(int id, PatchCartDTO dto)
    {
        var cart = await _repository.GetByIdAsync(id);
        if (cart is null) return null;

        if (dto.UuserId is not null) cart.UuserId = dto.UuserId.Value;
        cart.UpdateDate = DateTime.UtcNow;

        _repository.Update(cart);
        await _repository.SaveChangesAsync();
        return _mapper.Map<CartDTO>(cart);
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var cart = await _repository.GetByIdAsync(id);
        if (cart is null) return false;

        _repository.Remove(cart);
        await _repository.SaveChangesAsync();
        return true;
    }
}