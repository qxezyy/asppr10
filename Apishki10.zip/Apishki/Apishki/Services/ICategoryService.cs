﻿using Apishki.DTOs.Category;
namespace Apishki.Services;

public interface ICategoryService
{
    Task<(List<CategoryDTO> Items, int Total)> GetAllAsync(int page, int pageSize);
    Task<CategoryDTO?> GetByIdAsync(int id);
    Task<CategoryDTO> CreateAsync(CreateCategoryDTO dto);
    Task<CategoryDTO?> UpdateAsync(int id, UpdateCategoryDTO dto);
    Task<CategoryDTO?> PatchAsync(int id, PatchCategoryDTO dto);
    Task<bool> DeleteAsync(int id);
}