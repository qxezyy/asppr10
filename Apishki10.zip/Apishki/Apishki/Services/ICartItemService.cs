﻿using Apishki.DTOs.CartItem;
namespace Apishki.Services;

public interface ICartItemService
{
    Task<(List<CartItemDTO> Items, int Total)> GetAllAsync(int page, int pageSize);
    Task<CartItemDTO?> GetByIdAsync(int id);
    Task<CartItemDTO> CreateAsync(CreateCartItemDTO dto);
    Task<CartItemDTO?> UpdateAsync(int id, UpdateCartItemDTO dto);
    Task<CartItemDTO?> PatchAsync(int id, PatchCartItemDTO dto);
    Task<bool> DeleteAsync(int id);
}