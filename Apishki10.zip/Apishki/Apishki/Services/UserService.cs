﻿using AutoMapper;
using Apishki.DTOs.User;
using Apishki.Models;
using Apishki.Repositories;
namespace Apishki.Services;

public class UserService : IUserService
{
    private readonly IUserRepository _repository;
    private readonly IRoleRepository _roleRepo;
    private readonly IMapper _mapper;

    public UserService(IUserRepository repository, IRoleRepository roleRepo, IMapper mapper)
    {
        _repository = repository; _roleRepo = roleRepo; _mapper = mapper;
    }

    public async Task<(List<UserDTO>, int)> GetAllAsync(int page, int pageSize)
    {
        var items = await _repository.GetAllAsync(page, pageSize);
        var total = await _repository.CountAsync();
        return (_mapper.Map<List<UserDTO>>(items), total);
    }

    public async Task<UserDTO?> GetByIdAsync(int id)
    {
        var u = await _repository.GetByIdAsync(id);
        return u is null ? null : _mapper.Map<UserDTO>(u);
    }

    public async Task<UserDTO> CreateAsync(CreateUserDTO dto)
    {
        _ = await _roleRepo.GetByIdAsync(dto.RoleId)
            ?? throw new KeyNotFoundException($"Роль с id={dto.RoleId} не найдена");

        var u = _mapper.Map<User>(dto);
        u.RegistrationDate = DateTime.UtcNow;

        await _repository.AddAsync(u);
        await _repository.SaveChangesAsync();

        var saved = await _repository.GetByIdAsync(u.IdUser);
        return _mapper.Map<UserDTO>(saved!);
    }

    public async Task<UserDTO?> UpdateAsync(int id, UpdateUserDTO dto)
    {
        var u = await _repository.GetByIdAsync(id);
        if (u is null) return null;
        _mapper.Map(dto, u);
        _repository.Update(u);
        await _repository.SaveChangesAsync();
        return _mapper.Map<UserDTO>(u);
    }

    public async Task<UserDTO?> PatchAsync(int id, PatchUserDTO dto)
    {
        var u = await _repository.GetByIdAsync(id);
        if (u is null) return null;

        if (dto.LoginUser is not null) u.LoginUser = dto.LoginUser;
        if (dto.PasswordUser is not null) u.PasswordUser = dto.PasswordUser;
        if (dto.RoleId is not null) u.RoleId = dto.RoleId.Value;
        if (dto.Email is not null) u.Email = dto.Email;
        if (dto.IsActive is not null) u.IsActive = dto.IsActive.Value;

        _repository.Update(u);
        await _repository.SaveChangesAsync();
        return _mapper.Map<UserDTO>(u);
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var u = await _repository.GetByIdAsync(id);
        if (u is null) return false;
        _repository.Remove(u);
        await _repository.SaveChangesAsync();
        return true;
    }
}