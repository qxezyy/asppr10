﻿using Apishki.DTOs.Cart;
namespace Apishki.Services;

public interface ICartService
{
    Task<(List<CartDTO> Items, int Total)> GetAllAsync(int page, int pageSize);
    Task<CartDTO?> GetByIdAsync(int id);
    Task<CartDTO> CreateAsync(CreateCartDTO dto);
    Task<CartDTO?> UpdateAsync(int id, UpdateCartDTO dto);
    Task<CartDTO?> PatchAsync(int id, PatchCartDTO dto);
    Task<bool> DeleteAsync(int id);
}