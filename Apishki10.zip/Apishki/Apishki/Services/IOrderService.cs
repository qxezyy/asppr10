﻿using Apishki.DTOs.Order;
namespace Apishki.Services;

public interface IOrderService
{
    Task<(List<OrderDTO> Items, int Total)> GetAllAsync(int page, int pageSize);
    Task<OrderDTO?> GetByIdAsync(int id);
    Task<OrderDTO> CreateAsync(CreateOrderDTO dto);
    Task<OrderDTO?> UpdateAsync(int id, UpdateOrderDTO dto);
    Task<OrderDTO?> PatchAsync(int id, PatchOrderDTO dto);
    Task<bool> DeleteAsync(int id);
}