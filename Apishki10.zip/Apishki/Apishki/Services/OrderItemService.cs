﻿using AutoMapper;
using Apishki.DTOs.OrderItem;
using Apishki.Models;
using Apishki.Repositories;
namespace Apishki.Services;

public class OrderItemService : IOrderItemService
{
    private readonly IOrderItemRepository _repository;
    private readonly IOrderRepository _orderRepo;
    private readonly IProductRepository _productRepo;
    private readonly IMapper _mapper;

    public OrderItemService(IOrderItemRepository repository, IOrderRepository orderRepo,
        IProductRepository productRepo, IMapper mapper)
    {
        _repository = repository; _orderRepo = orderRepo;
        _productRepo = productRepo; _mapper = mapper;
    }

    public async Task<(List<OrderItemDTO>, int)> GetAllAsync(int page, int pageSize)
    {
        var items = await _repository.GetAllAsync(page, pageSize);
        var total = await _repository.CountAsync();
        return (_mapper.Map<List<OrderItemDTO>>(items), total);
    }

    public async Task<OrderItemDTO?> GetByIdAsync(int id)
    {
        var oi = await _repository.GetByIdAsync(id);
        return oi is null ? null : _mapper.Map<OrderItemDTO>(oi);
    }

    public async Task<OrderItemDTO> CreateAsync(CreateOrderItemDTO dto)
    {
        if (await _orderRepo.GetByIdAsync(dto.OrderId) is null)
            throw new KeyNotFoundException($"Заказ с id={dto.OrderId} не найден");
        if (await _productRepo.GetByIdAsync(dto.ProductId) is null)
            throw new KeyNotFoundException($"Товар с id={dto.ProductId} не найден");

        var oi = _mapper.Map<OrderItem>(dto);
        await _repository.AddAsync(oi);
        await _repository.SaveChangesAsync();

        var saved = await _repository.GetByIdAsync(oi.IdOrderitem);
        return _mapper.Map<OrderItemDTO>(saved!);
    }

    public async Task<OrderItemDTO?> UpdateAsync(int id, UpdateOrderItemDTO dto)
    {
        var oi = await _repository.GetByIdAsync(id);
        if (oi is null) return null;
        _mapper.Map(dto, oi);
        _repository.Update(oi);
        await _repository.SaveChangesAsync();
        return _mapper.Map<OrderItemDTO>(oi);
    }

    public async Task<OrderItemDTO?> PatchAsync(int id, PatchOrderItemDTO dto)
    {
        var oi = await _repository.GetByIdAsync(id);
        if (oi is null) return null;

        if (dto.OrderId is not null) oi.OrderId = dto.OrderId.Value;
        if (dto.ProductId is not null) oi.ProductId = dto.ProductId.Value;
        if (dto.Title is not null) oi.Title = dto.Title;
        if (dto.Price is not null) oi.Price = dto.Price.Value;
        if (dto.Quantity is not null) oi.Quantity = dto.Quantity.Value;

        _repository.Update(oi);
        await _repository.SaveChangesAsync();
        return _mapper.Map<OrderItemDTO>(oi);
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var oi = await _repository.GetByIdAsync(id);
        if (oi is null) return false;
        _repository.Remove(oi);
        await _repository.SaveChangesAsync();
        return true;
    }
}