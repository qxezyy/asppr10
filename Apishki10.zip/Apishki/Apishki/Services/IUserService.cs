﻿using Apishki.DTOs.User;
namespace Apishki.Services;

public interface IUserService
{
    Task<(List<UserDTO> Items, int Total)> GetAllAsync(int page, int pageSize);
    Task<UserDTO?> GetByIdAsync(int id);
    Task<UserDTO> CreateAsync(CreateUserDTO dto);
    Task<UserDTO?> UpdateAsync(int id, UpdateUserDTO dto);
    Task<UserDTO?> PatchAsync(int id, PatchUserDTO dto);
    Task<bool> DeleteAsync(int id);
}