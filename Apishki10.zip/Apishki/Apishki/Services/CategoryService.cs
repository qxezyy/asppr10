﻿using AutoMapper;
using Apishki.DTOs.Category;
using Apishki.Models;
using Apishki.Repositories;
namespace Apishki.Services;

public class CategoryService : ICategoryService
{
    private readonly ICategoryRepository _repository;
    private readonly IMapper _mapper;

    public CategoryService(ICategoryRepository repository, IMapper mapper)
    {
        _repository = repository; _mapper = mapper;
    }

    public async Task<(List<CategoryDTO>, int)> GetAllAsync(int page, int pageSize)
    {
        var items = await _repository.GetAllAsync(page, pageSize);
        var total = await _repository.CountAsync();
        return (_mapper.Map<List<CategoryDTO>>(items), total);
    }

    public async Task<CategoryDTO?> GetByIdAsync(int id)
    {
        var c = await _repository.GetByIdAsync(id);
        return c is null ? null : _mapper.Map<CategoryDTO>(c);
    }

    public async Task<CategoryDTO> CreateAsync(CreateCategoryDTO dto)
    {
        var c = _mapper.Map<Category>(dto);
        await _repository.AddAsync(c);
        await _repository.SaveChangesAsync();
        return _mapper.Map<CategoryDTO>(c);
    }

    public async Task<CategoryDTO?> UpdateAsync(int id, UpdateCategoryDTO dto)
    {
        var c = await _repository.GetByIdAsync(id);
        if (c is null) return null;
        _mapper.Map(dto, c);
        _repository.Update(c);
        await _repository.SaveChangesAsync();
        return _mapper.Map<CategoryDTO>(c);
    }

    public async Task<CategoryDTO?> PatchAsync(int id, PatchCategoryDTO dto)
    {
        var c = await _repository.GetByIdAsync(id);
        if (c is null) return null;
        if (dto.Title is not null) c.Title = dto.Title;
        _repository.Update(c);
        await _repository.SaveChangesAsync();
        return _mapper.Map<CategoryDTO>(c);
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var c = await _repository.GetByIdAsync(id);
        if (c is null) return false;
        _repository.Remove(c);
        await _repository.SaveChangesAsync();
        return true;
    }
}