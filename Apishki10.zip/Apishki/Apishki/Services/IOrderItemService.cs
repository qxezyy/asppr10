﻿using Apishki.DTOs.OrderItem;
namespace Apishki.Services;

public interface IOrderItemService
{
    Task<(List<OrderItemDTO> Items, int Total)> GetAllAsync(int page, int pageSize);
    Task<OrderItemDTO?> GetByIdAsync(int id);
    Task<OrderItemDTO> CreateAsync(CreateOrderItemDTO dto);
    Task<OrderItemDTO?> UpdateAsync(int id, UpdateOrderItemDTO dto);
    Task<OrderItemDTO?> PatchAsync(int id, PatchOrderItemDTO dto);
    Task<bool> DeleteAsync(int id);
}