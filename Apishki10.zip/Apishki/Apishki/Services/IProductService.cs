﻿using Apishki.DTOs.Product;

namespace Apishki.Services;

public interface IProductService
{
    Task<(List<ProductReadDto> Items, int Total)> GetAllAsync(int page, int pageSize);
    Task<ProductReadDto?> GetByIdAsync(int id);
    Task<ProductReadDto> CreateAsync(CreateProductDto dto);
    Task<ProductReadDto?> UpdateAsync(int id, UpdateProductDto dto);
    Task<ProductReadDto?> PatchAsync(int id, PatchProductDto dto);
    Task<bool> DeleteAsync(int id);
}