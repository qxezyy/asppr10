﻿using AutoMapper;
using Apishki.DTOs.Reservation;
using Apishki.Models;
using Apishki.Repositories;

namespace Apishki.Services;

public class ReservationService : IReservationService
{
    private readonly IReservationRepository _reservationRepo;
    private readonly IProductRepository _productRepo;
    private readonly IMapper _mapper;

    public ReservationService(
        IReservationRepository reservationRepo,
        IProductRepository productRepo,
        IMapper mapper)
    {
        _reservationRepo = reservationRepo;
        _productRepo = productRepo;
        _mapper = mapper;
    }

    public async Task<(List<ReservationReadDto>, int)> GetAllAsync(int page, int pageSize)
    {
        var items = await _reservationRepo.GetAllAsync(page, pageSize);
        var total = await _reservationRepo.CountAsync();
        return (_mapper.Map<List<ReservationReadDto>>(items), total);
    }

    public async Task<ReservationReadDto?> GetByIdAsync(int id)
    {
        var r = await _reservationRepo.GetByIdAsync(id);
        return r is null ? null : _mapper.Map<ReservationReadDto>(r);
    }

    public async Task<ReservationReadDto> ReserveAsync(CreateReservationDto dto)
    {
        var product = await _productRepo.GetByIdAsync(dto.ProductId);
        if (product is null)
            throw new KeyNotFoundException($"Товар с id={dto.ProductId} не найден");

        if (product.Stock < dto.Quantity)
            throw new InvalidOperationException($"Недостаточно товара на складе. Доступно: {product.Stock}, запрошено: {dto.Quantity}");

        product.Stock -= dto.Quantity;

        var reservation = new Reservation
        {
            ProductId = dto.ProductId,
            Quantity = dto.Quantity,
            Status = "Active",
            CreatedAt = DateTime.UtcNow
        };
        await _reservationRepo.AddAsync(reservation); 

        await _reservationRepo.SaveChangesAsync();

        var saved = await _reservationRepo.GetByIdAsync(reservation.IdReservation);
        return _mapper.Map<ReservationReadDto>(saved!);
    }

    public async Task<bool> CancelAsync(int id)
    {
        var reservation = await _reservationRepo.GetByIdAsync(id);
        if (reservation is null || reservation.Status != "Active")
            return false; 

        var product = await _productRepo.GetByIdAsync(reservation.ProductId);
        if (product is not null)
            product.Stock += reservation.Quantity;

        reservation.Status = "Cancelled";
        reservation.CancelledAt = DateTime.UtcNow;

        await _reservationRepo.SaveChangesAsync();
        return true;
    }
}