﻿using Apishki.DTOs.Cart;
using Apishki.DTOs.CartItem;
using Apishki.DTOs.Category;
using Apishki.DTOs.Order;
using Apishki.DTOs.OrderItem;
using Apishki.DTOs.Product;
using Apishki.DTOs.Reservation;
using Apishki.DTOs.Role;
using Apishki.DTOs.User;
using Apishki.Models;
using AutoMapper;

namespace Apishki.Mapping;

public class MappingProfile : Profile
{
    public MappingProfile()
    {
        CreateMap<Product, ProductReadDto>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.IdProduct))
            .ForMember(dest => dest.CategoryName, opt => opt.MapFrom(src => src.Category.Title))
            .ForMember(dest => dest.CreatedAt, opt => opt.MapFrom(src => src.RegistrationDate));
        CreateMap<CreateProductDto, Product>()
            .ForMember(dest => dest.IdProduct, opt => opt.Ignore())
            .ForMember(dest => dest.RegistrationDate, opt => opt.Ignore())
            .ForMember(dest => dest.Category, opt => opt.Ignore())
            .ForMember(dest => dest.CartItems, opt => opt.Ignore())
            .ForMember(dest => dest.OrderItems, opt => opt.Ignore());
        CreateMap<UpdateProductDto, Product>()
            .ForMember(dest => dest.IdProduct, opt => opt.Ignore())
            .ForMember(dest => dest.RegistrationDate, opt => opt.Ignore())
            .ForMember(dest => dest.Category, opt => opt.Ignore())
            .ForMember(dest => dest.CartItems, opt => opt.Ignore())
            .ForMember(dest => dest.OrderItems, opt => opt.Ignore());

        CreateMap<Reservation, ReservationReadDto>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.IdReservation))
            .ForMember(dest => dest.ProductTitle, opt => opt.MapFrom(src => src.Product.Title));

        CreateMap<Cart, CartDTO>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.IdCart))
            .ForMember(dest => dest.CreatedAt, opt => opt.MapFrom(src => src.CreationDate))
            .ForMember(dest => dest.LoginUser, opt => opt.MapFrom(src => src.Uuser.LoginUser));
        CreateMap<CreateCartDTO, Cart>()
            .ForMember(dest => dest.IdCart, opt => opt.Ignore())
            .ForMember(dest => dest.CreationDate, opt => opt.Ignore())
            .ForMember(dest => dest.UpdateDate, opt => opt.Ignore())
            .ForMember(dest => dest.Uuser, opt => opt.Ignore())
            .ForMember(dest => dest.CartItems, opt => opt.Ignore());
        CreateMap<UpdateCartDTO, Cart>()
            .ForMember(dest => dest.IdCart, opt => opt.Ignore())
            .ForMember(dest => dest.CreationDate, opt => opt.Ignore())
            .ForMember(dest => dest.UpdateDate, opt => opt.Ignore())
            .ForMember(dest => dest.Uuser, opt => opt.Ignore())
            .ForMember(dest => dest.CartItems, opt => opt.Ignore());

        CreateMap<CartItem, CartItemDTO>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.IdCartitem))
            .ForMember(dest => dest.ProductTitle, opt => opt.MapFrom(src => src.Product.Title));
        CreateMap<CreateCartItemDTO, CartItem>()
            .ForMember(dest => dest.IdCartitem, opt => opt.Ignore())
            .ForMember(dest => dest.Cart, opt => opt.Ignore())
            .ForMember(dest => dest.Product, opt => opt.Ignore());
        CreateMap<UpdateCartItemDTO, CartItem>()
            .ForMember(dest => dest.IdCartitem, opt => opt.Ignore())
            .ForMember(dest => dest.Cart, opt => opt.Ignore())
            .ForMember(dest => dest.Product, opt => opt.Ignore());

        CreateMap<Category, CategoryDTO>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.IdCategory));
        CreateMap<CreateCategoryDTO, Category>()
            .ForMember(dest => dest.IdCategory, opt => opt.Ignore())
            .ForMember(dest => dest.Products, opt => opt.Ignore());
        CreateMap<UpdateCategoryDTO, Category>()
            .ForMember(dest => dest.IdCategory, opt => opt.Ignore())
            .ForMember(dest => dest.Products, opt => opt.Ignore());

        CreateMap<Order, OrderDTO>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.IdOrder))
            .ForMember(dest => dest.CreatedAt, opt => opt.MapFrom(src => src.OrderDate))
            .ForMember(dest => dest.LoginUser, opt => opt.MapFrom(src => src.Uuser.LoginUser));
        CreateMap<CreateOrderDTO, Order>()
            .ForMember(dest => dest.IdOrder, opt => opt.Ignore())
            .ForMember(dest => dest.OrderDate, opt => opt.Ignore())
            .ForMember(dest => dest.Uuser, opt => opt.Ignore())
            .ForMember(dest => dest.OrderItems, opt => opt.Ignore());
        CreateMap<UpdateOrderDTO, Order>()
            .ForMember(dest => dest.IdOrder, opt => opt.Ignore())
            .ForMember(dest => dest.OrderDate, opt => opt.Ignore())
            .ForMember(dest => dest.Uuser, opt => opt.Ignore())
            .ForMember(dest => dest.OrderItems, opt => opt.Ignore());

        CreateMap<OrderItem, OrderItemDTO>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.IdOrderitem))
            .ForMember(dest => dest.ProductTitle, opt => opt.MapFrom(src => src.Product.Title));
        CreateMap<CreateOrderItemDTO, OrderItem>()
            .ForMember(dest => dest.IdOrderitem, opt => opt.Ignore())
            .ForMember(dest => dest.Order, opt => opt.Ignore())
            .ForMember(dest => dest.Product, opt => opt.Ignore());
        CreateMap<UpdateOrderItemDTO, OrderItem>()
            .ForMember(dest => dest.IdOrderitem, opt => opt.Ignore())
            .ForMember(dest => dest.Order, opt => opt.Ignore())
            .ForMember(dest => dest.Product, opt => opt.Ignore());

        CreateMap<Role, RoleDTO>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.IdRole));
        CreateMap<CreateRoleDTO, Role>()
            .ForMember(dest => dest.IdRole, opt => opt.Ignore())
            .ForMember(dest => dest.Users, opt => opt.Ignore());
        CreateMap<UpdateRoleDTO, Role>()
            .ForMember(dest => dest.IdRole, opt => opt.Ignore())
            .ForMember(dest => dest.Users, opt => opt.Ignore());

        CreateMap<User, UserDTO>()
            .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.IdUser))
            .ForMember(dest => dest.CreatedAt, opt => opt.MapFrom(src => src.RegistrationDate))
            .ForMember(dest => dest.RoleTitle, opt => opt.MapFrom(src => src.Role.Title));
        CreateMap<CreateUserDTO, User>()
            .ForMember(dest => dest.IdUser, opt => opt.Ignore())
            .ForMember(dest => dest.RegistrationDate, opt => opt.Ignore())
            .ForMember(dest => dest.Role, opt => opt.Ignore())
            .ForMember(dest => dest.Cart, opt => opt.Ignore())
            .ForMember(dest => dest.Orders, opt => opt.Ignore());
        CreateMap<UpdateUserDTO, User>()
            .ForMember(dest => dest.IdUser, opt => opt.Ignore())
            .ForMember(dest => dest.RegistrationDate, opt => opt.Ignore())
            .ForMember(dest => dest.Role, opt => opt.Ignore())
            .ForMember(dest => dest.Cart, opt => opt.Ignore())
            .ForMember(dest => dest.Orders, opt => opt.Ignore());
    }
}