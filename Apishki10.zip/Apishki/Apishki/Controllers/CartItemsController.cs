﻿using Apishki.DTOs.CartItem;
using Apishki.Services;
using Microsoft.AspNetCore.Mvc;

namespace Apishki.Controllers;

[ApiController]
[Route("api/cart-items")]
public class CartItemsController : ControllerBase
{
    private readonly ICartItemService _service;
    public CartItemsController(ICartItemService service) => _service = service;

    [HttpGet]
    public async Task<IActionResult> GetAll(int page = 1, int pageSize = 10)
    {
        var (items, total) = await _service.GetAllAsync(page, pageSize);
        Response.Headers["X-Total-Count"] = total.ToString();
        return Ok(items);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var ci = await _service.GetByIdAsync(id);
        return ci is null ? NotFound() : Ok(ci);
    }

    [HttpPost]
    public async Task<IActionResult> Create(CreateCartItemDTO dto)
    {
        try
        {
            var ci = await _service.CreateAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = ci.Id }, ci);
        }
        catch (KeyNotFoundException ex) { return BadRequest(new { error = ex.Message }); }
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(int id, UpdateCartItemDTO dto)
    {
        var ci = await _service.UpdateAsync(id, dto);
        return ci is null ? NotFound() : NoContent();
    }

    [HttpPatch("{id}")]
    public async Task<IActionResult> Patch(int id, PatchCartItemDTO dto)
    {
        var ci = await _service.PatchAsync(id, dto);
        return ci is null ? NotFound() : NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var ok = await _service.DeleteAsync(id);
        return ok ? NoContent() : NotFound();
    }
}