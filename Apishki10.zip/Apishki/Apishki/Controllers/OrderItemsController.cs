﻿using Apishki.DTOs.OrderItem;
using Apishki.Services;
using Microsoft.AspNetCore.Mvc;

namespace Apishki.Controllers;

[ApiController]
[Route("api/order-items")]
public class OrderItemsController : ControllerBase
{
    private readonly IOrderItemService _service;
    public OrderItemsController(IOrderItemService service) => _service = service;

    [HttpGet]
    public async Task<IActionResult> GetAll(int page = 1, int pageSize = 10)
    {
        var (items, total) = await _service.GetAllAsync(page, pageSize);
        Response.Headers["X-Total-Count"] = total.ToString();
        return Ok(items);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var oi = await _service.GetByIdAsync(id);
        return oi is null ? NotFound() : Ok(oi);
    }

    [HttpPost]
    public async Task<IActionResult> Create(CreateOrderItemDTO dto)
    {
        try
        {
            var oi = await _service.CreateAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = oi.Id }, oi);
        }
        catch (KeyNotFoundException ex) { return BadRequest(new { error = ex.Message }); }
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(int id, UpdateOrderItemDTO dto)
    {
        var oi = await _service.UpdateAsync(id, dto);
        return oi is null ? NotFound() : NoContent();
    }

    [HttpPatch("{id}")]
    public async Task<IActionResult> Patch(int id, PatchOrderItemDTO dto)
    {
        var oi = await _service.PatchAsync(id, dto);
        return oi is null ? NotFound() : NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var ok = await _service.DeleteAsync(id);
        return ok ? NoContent() : NotFound();
    }
}