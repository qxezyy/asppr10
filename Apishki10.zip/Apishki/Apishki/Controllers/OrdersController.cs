﻿using Apishki.DTOs.Order;
using Apishki.Services;
using Microsoft.AspNetCore.Mvc;

namespace Apishki.Controllers;

[ApiController]
[Route("api/orders")]
public class OrdersController : ControllerBase
{
    private readonly IOrderService _service;
    public OrdersController(IOrderService service) => _service = service;

    [HttpGet]
    public async Task<IActionResult> GetAll(int page = 1, int pageSize = 10)
    {
        var (items, total) = await _service.GetAllAsync(page, pageSize);
        Response.Headers["X-Total-Count"] = total.ToString();
        return Ok(items);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var o = await _service.GetByIdAsync(id);
        return o is null ? NotFound() : Ok(o);
    }

    [HttpPost]
    public async Task<IActionResult> Create(CreateOrderDTO dto)
    {
        try
        {
            var o = await _service.CreateAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = o.Id }, o);
        }
        catch (KeyNotFoundException ex) { return BadRequest(new { error = ex.Message }); }
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(int id, UpdateOrderDTO dto)
    {
        var o = await _service.UpdateAsync(id, dto);
        return o is null ? NotFound() : NoContent();
    }

    [HttpPatch("{id}")]
    public async Task<IActionResult> Patch(int id, PatchOrderDTO dto)
    {
        var o = await _service.PatchAsync(id, dto);
        return o is null ? NotFound() : NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var ok = await _service.DeleteAsync(id);
        return ok ? NoContent() : NotFound();
    }
}