﻿using Apishki.DTOs.User;
using Apishki.Services;
using Microsoft.AspNetCore.Mvc;

namespace Apishki.Controllers;

[ApiController]
[Route("api/users")]
public class UsersController : ControllerBase
{
    private readonly IUserService _service;
    public UsersController(IUserService service) => _service = service;

    [HttpGet]
    public async Task<IActionResult> GetAll(int page = 1, int pageSize = 10)
    {
        var (items, total) = await _service.GetAllAsync(page, pageSize);
        Response.Headers["X-Total-Count"] = total.ToString();
        return Ok(items);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var u = await _service.GetByIdAsync(id);
        return u is null ? NotFound() : Ok(u);
    }

    [HttpPost]
    public async Task<IActionResult> Create(CreateUserDTO dto)
    {
        try
        {
            var u = await _service.CreateAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = u.Id }, u);
        }
        catch (KeyNotFoundException ex) { return BadRequest(new { error = ex.Message }); }
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(int id, UpdateUserDTO dto)
    {
        var u = await _service.UpdateAsync(id, dto);
        return u is null ? NotFound() : NoContent();
    }

    [HttpPatch("{id}")]
    public async Task<IActionResult> Patch(int id, PatchUserDTO dto)
    {
        var u = await _service.PatchAsync(id, dto);
        return u is null ? NotFound() : NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var ok = await _service.DeleteAsync(id);
        return ok ? NoContent() : NotFound();
    }
}