﻿using Apishki.DTOs.Reservation;
using Apishki.Services;
using Microsoft.AspNetCore.Mvc;

namespace Apishki.Controllers;

[ApiController]
[Route("api/reservations")]
public class ReservationsController : ControllerBase
{
    private readonly IReservationService _service;

    public ReservationsController(IReservationService service) => _service = service;

    [HttpGet]
    public async Task<IActionResult> GetAll(int page = 1, int pageSize = 10)
    {
        var (items, total) = await _service.GetAllAsync(page, pageSize);
        Response.Headers["X-Total-Count"] = total.ToString();
        return Ok(items);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var r = await _service.GetByIdAsync(id);
        return r is null ? NotFound() : Ok(r);
    }

    [HttpPost("reserve")]
    public async Task<IActionResult> Reserve(CreateReservationDto dto)
    {
        try
        {
            var r = await _service.ReserveAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = r.Id }, r);
        }
        catch (KeyNotFoundException ex) { return NotFound(new { error = ex.Message }); }
        catch (InvalidOperationException ex) { return BadRequest(new { error = ex.Message }); }
    }

    [HttpPost("{id}/cancel")]
    public async Task<IActionResult> Cancel(int id)
    {
        var cancelled = await _service.CancelAsync(id);
        return cancelled ? NoContent() : NotFound(new { error = "Активная бронь не найдена" });
    }
}