﻿namespace Apishki.DTOs.Reservation;

public class ReservationReadDto
{
    public int Id { get; set; }
    public int ProductId { get; set; }
    public string ProductTitle { get; set; } = null!;
    public int Quantity { get; set; }
    public string Status { get; set; } = null!;
    public DateTime CreatedAt { get; set; }
    public DateTime? CancelledAt { get; set; }
}