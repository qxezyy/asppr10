﻿namespace Apishki.DTOs.Reservation;

public class CreateReservationDto
{
    public int ProductId { get; set; }
    public int Quantity { get; set; }
}