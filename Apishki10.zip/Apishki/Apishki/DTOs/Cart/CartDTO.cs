﻿namespace Apishki.DTOs.Cart;

public class CartDTO
{
    public int Id { get; set; }
    public int UuserId { get; set; }
    public string LoginUser { get; set; } = null!;   
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdateDate { get; set; }
}