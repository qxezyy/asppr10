﻿namespace Apishki.DTOs.CartItem;

public class CartItemDTO
{
    public int Id { get; set; }
    public int CartId { get; set; }
    public int ProductId { get; set; }
    public string ProductTitle { get; set; } = null!; 
    public int Quantity { get; set; }
}