﻿namespace Apishki.DTOs.Product;

public class UpdateProductDto
{
    public string Title { get; set; } = null!;
    public decimal Price { get; set; }
    public int CategoryId { get; set; }
    public string? Description { get; set; }
    public string? Image { get; set; }
    public int Stock { get; set; }
}