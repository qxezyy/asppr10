﻿namespace Apishki.DTOs.Product;

public class ProductReadDto
{
    public int Id { get; set; }
    public string Title { get; set; } = null!;
    public decimal Price { get; set; }
    public int CategoryId { get; set; }
    public string CategoryName { get; set; } = null!;
    public string? Description { get; set; }
    public string? Image { get; set; }
    public int Stock { get; set; }
    public DateTime CreatedAt { get; set; }
}