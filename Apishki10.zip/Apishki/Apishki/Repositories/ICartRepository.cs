﻿using Apishki.Models;
namespace Apishki.Repositories;

public interface ICartRepository
{
    Task<List<Cart>> GetAllAsync(int page, int pageSize);
    Task<Cart?> GetByIdAsync(int id);
    Task<int> CountAsync();
    Task AddAsync(Cart cart);
    void Update(Cart cart);
    void Remove(Cart cart);
    Task SaveChangesAsync();
}