﻿using Apishki.Models;
namespace Apishki.Repositories;

public interface IRoleRepository
{
    Task<List<Role>> GetAllAsync(int page, int pageSize);
    Task<Role?> GetByIdAsync(int id);
    Task<int> CountAsync();
    Task AddAsync(Role role);
    void Update(Role role);
    void Remove(Role role);
    Task SaveChangesAsync();
}