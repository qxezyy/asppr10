﻿using Apishki.Models;
namespace Apishki.Repositories;

public interface ICategoryRepository
{
    Task<List<Category>> GetAllAsync(int page, int pageSize);
    Task<Category?> GetByIdAsync(int id);
    Task<int> CountAsync();
    Task AddAsync(Category category);
    void Update(Category category);
    void Remove(Category category);
    Task SaveChangesAsync();
}