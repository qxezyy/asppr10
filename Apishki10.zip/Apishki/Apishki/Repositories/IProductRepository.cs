﻿using Apishki.Models;

namespace Apishki.Repositories;

public interface IProductRepository
{
    Task<List<Product>> GetAllAsync(int page, int pageSize);
    Task<Product?> GetByIdAsync(int id);
    Task<int> CountAsync();
    Task AddAsync(Product product);
    void Update(Product product);
    void Remove(Product product);
    Task SaveChangesAsync();
}