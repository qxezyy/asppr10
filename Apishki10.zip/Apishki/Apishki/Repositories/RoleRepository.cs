﻿using Apishki.Models;
using Microsoft.EntityFrameworkCore;
namespace Apishki.Repositories;

public class RoleRepository : IRoleRepository
{
    private readonly Db33Context _context;
    public RoleRepository(Db33Context context) => _context = context;

    public async Task<List<Role>> GetAllAsync(int page, int pageSize)
        => await _context.Roles
            .OrderBy(r => r.IdRole)
            .Skip((page - 1) * pageSize).Take(pageSize)
            .ToListAsync();

    public async Task<Role?> GetByIdAsync(int id)
        => await _context.Roles.FirstOrDefaultAsync(r => r.IdRole == id);

    public async Task<int> CountAsync() => await _context.Roles.CountAsync();
    public async Task AddAsync(Role r) => await _context.Roles.AddAsync(r);
    public void Update(Role r) => _context.Roles.Update(r);
    public void Remove(Role r) => _context.Roles.Remove(r);
    public async Task SaveChangesAsync() => await _context.SaveChangesAsync();
}