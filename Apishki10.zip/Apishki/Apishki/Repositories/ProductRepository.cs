﻿using Apishki.Models;
using Microsoft.EntityFrameworkCore;

namespace Apishki.Repositories;

public class ProductRepository : IProductRepository
{
    private readonly Db33Context _context;

    public ProductRepository(Db33Context context) => _context = context;

    public async Task<List<Product>> GetAllAsync(int page, int pageSize)
        => await _context.Products
            .Include(p => p.Category)
            .OrderBy(p => p.IdProduct)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync();

    public async Task<Product?> GetByIdAsync(int id)
        => await _context.Products
            .Include(p => p.Category)
            .FirstOrDefaultAsync(p => p.IdProduct == id);

    public async Task<int> CountAsync() => await _context.Products.CountAsync();
    public async Task AddAsync(Product p) => await _context.Products.AddAsync(p);
    public void Update(Product p) => _context.Products.Update(p);
    public void Remove(Product p) => _context.Products.Remove(p);
    public async Task SaveChangesAsync() => await _context.SaveChangesAsync();
}