﻿using Apishki.Models;
using Microsoft.EntityFrameworkCore;
namespace Apishki.Repositories;

public class UserRepository : IUserRepository
{
    private readonly Db33Context _context;
    public UserRepository(Db33Context context) => _context = context;

    public async Task<List<User>> GetAllAsync(int page, int pageSize)
        => await _context.Users
            .Include(u => u.Role)
            .OrderBy(u => u.IdUser)
            .Skip((page - 1) * pageSize).Take(pageSize)
            .ToListAsync();

    public async Task<User?> GetByIdAsync(int id)
        => await _context.Users
            .Include(u => u.Role)
            .FirstOrDefaultAsync(u => u.IdUser == id);

    public async Task<int> CountAsync() => await _context.Users.CountAsync();
    public async Task AddAsync(User u) => await _context.Users.AddAsync(u);
    public void Update(User u) => _context.Users.Update(u);
    public void Remove(User u) => _context.Users.Remove(u);
    public async Task SaveChangesAsync() => await _context.SaveChangesAsync();
}