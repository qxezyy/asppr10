﻿using Apishki.Models;
namespace Apishki.Repositories;

public interface IOrderRepository
{
    Task<List<Order>> GetAllAsync(int page, int pageSize);
    Task<Order?> GetByIdAsync(int id);
    Task<int> CountAsync();
    Task AddAsync(Order order);
    void Update(Order order);
    void Remove(Order order);
    Task SaveChangesAsync();
}