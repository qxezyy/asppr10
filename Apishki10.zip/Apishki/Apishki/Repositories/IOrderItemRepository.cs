﻿using Apishki.Models;
namespace Apishki.Repositories;

public interface IOrderItemRepository
{
    Task<List<OrderItem>> GetAllAsync(int page, int pageSize);
    Task<OrderItem?> GetByIdAsync(int id);
    Task<int> CountAsync();
    Task AddAsync(OrderItem item);
    void Update(OrderItem item);
    void Remove(OrderItem item);
    Task SaveChangesAsync();
}