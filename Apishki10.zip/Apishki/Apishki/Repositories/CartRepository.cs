﻿using Apishki.Models;
using Microsoft.EntityFrameworkCore;
namespace Apishki.Repositories;

public class CartRepository : ICartRepository
{
    private readonly Db33Context _context;
    public CartRepository(Db33Context context) => _context = context;

    public async Task<List<Cart>> GetAllAsync(int page, int pageSize)
        => await _context.Carts
            .Include(c => c.Uuser)
            .OrderBy(c => c.IdCart)
            .Skip((page - 1) * pageSize).Take(pageSize)
            .ToListAsync();

    public async Task<Cart?> GetByIdAsync(int id)
        => await _context.Carts
            .Include(c => c.Uuser)
            .FirstOrDefaultAsync(c => c.IdCart == id);

    public async Task<int> CountAsync() => await _context.Carts.CountAsync();
    public async Task AddAsync(Cart c) => await _context.Carts.AddAsync(c);
    public void Update(Cart c) => _context.Carts.Update(c);
    public void Remove(Cart c) => _context.Carts.Remove(c);
    public async Task SaveChangesAsync() => await _context.SaveChangesAsync();
}