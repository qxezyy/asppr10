﻿using Apishki.Models;

namespace Apishki.Repositories;

public interface IReservationRepository
{
    Task<List<Reservation>> GetAllAsync(int page, int pageSize);
    Task<Reservation?> GetByIdAsync(int id);
    Task<int> CountAsync();
    Task AddAsync(Reservation reservation);
    Task SaveChangesAsync();
}