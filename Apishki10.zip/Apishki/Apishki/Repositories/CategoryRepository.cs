﻿using Apishki.Models;
using Microsoft.EntityFrameworkCore;
namespace Apishki.Repositories;

public class CategoryRepository : ICategoryRepository
{
    private readonly Db33Context _context;
    public CategoryRepository(Db33Context context) => _context = context;

    public async Task<List<Category>> GetAllAsync(int page, int pageSize)
        => await _context.Categories
            .OrderBy(c => c.IdCategory)
            .Skip((page - 1) * pageSize).Take(pageSize)
            .ToListAsync();

    public async Task<Category?> GetByIdAsync(int id)
        => await _context.Categories.FirstOrDefaultAsync(c => c.IdCategory == id);

    public async Task<int> CountAsync() => await _context.Categories.CountAsync();
    public async Task AddAsync(Category c) => await _context.Categories.AddAsync(c);
    public void Update(Category c) => _context.Categories.Update(c);
    public void Remove(Category c) => _context.Categories.Remove(c);
    public async Task SaveChangesAsync() => await _context.SaveChangesAsync();
}