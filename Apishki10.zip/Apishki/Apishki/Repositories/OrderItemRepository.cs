﻿using Apishki.Models;
using Microsoft.EntityFrameworkCore;
namespace Apishki.Repositories;

public class OrderItemRepository : IOrderItemRepository
{
    private readonly Db33Context _context;
    public OrderItemRepository(Db33Context context) => _context = context;

    public async Task<List<OrderItem>> GetAllAsync(int page, int pageSize)
        => await _context.OrderItems
            .Include(oi => oi.Product)
            .OrderBy(oi => oi.IdOrderitem)
            .Skip((page - 1) * pageSize).Take(pageSize)
            .ToListAsync();

    public async Task<OrderItem?> GetByIdAsync(int id)
        => await _context.OrderItems
            .Include(oi => oi.Product)
            .FirstOrDefaultAsync(oi => oi.IdOrderitem == id);

    public async Task<int> CountAsync() => await _context.OrderItems.CountAsync();
    public async Task AddAsync(OrderItem oi) => await _context.OrderItems.AddAsync(oi);
    public void Update(OrderItem oi) => _context.OrderItems.Update(oi);
    public void Remove(OrderItem oi) => _context.OrderItems.Remove(oi);
    public async Task SaveChangesAsync() => await _context.SaveChangesAsync();
}