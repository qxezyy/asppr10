﻿using Apishki.Models;
using Microsoft.EntityFrameworkCore;
namespace Apishki.Repositories;

public class CartItemRepository : ICartItemRepository
{
    private readonly Db33Context _context;
    public CartItemRepository(Db33Context context) => _context = context;

    public async Task<List<CartItem>> GetAllAsync(int page, int pageSize)
        => await _context.CartItems
            .Include(ci => ci.Product)
            .OrderBy(ci => ci.IdCartitem)
            .Skip((page - 1) * pageSize).Take(pageSize)
            .ToListAsync();

    public async Task<CartItem?> GetByIdAsync(int id)
        => await _context.CartItems
            .Include(ci => ci.Product)
            .FirstOrDefaultAsync(ci => ci.IdCartitem == id);

    public async Task<int> CountAsync() => await _context.CartItems.CountAsync();
    public async Task AddAsync(CartItem ci) => await _context.CartItems.AddAsync(ci);
    public void Update(CartItem ci) => _context.CartItems.Update(ci);
    public void Remove(CartItem ci) => _context.CartItems.Remove(ci);
    public async Task SaveChangesAsync() => await _context.SaveChangesAsync();
}