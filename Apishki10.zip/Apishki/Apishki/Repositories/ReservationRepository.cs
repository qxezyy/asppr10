﻿using Apishki.Models;
using Microsoft.EntityFrameworkCore;

namespace Apishki.Repositories;

public class ReservationRepository : IReservationRepository
{
    private readonly Db33Context _context;

    public ReservationRepository(Db33Context context) => _context = context;

    public async Task<List<Reservation>> GetAllAsync(int page, int pageSize)
        => await _context.Reservations
            .Include(r => r.Product)
            .OrderBy(r => r.IdReservation)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync();

    public async Task<Reservation?> GetByIdAsync(int id)
        => await _context.Reservations
            .Include(r => r.Product)
            .FirstOrDefaultAsync(r => r.IdReservation == id);

    public async Task<int> CountAsync() => await _context.Reservations.CountAsync();
    public async Task AddAsync(Reservation r) => await _context.Reservations.AddAsync(r);
    public async Task SaveChangesAsync() => await _context.SaveChangesAsync();
}