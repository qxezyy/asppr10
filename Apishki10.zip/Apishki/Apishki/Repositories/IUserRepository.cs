﻿using Apishki.Models;
namespace Apishki.Repositories;

public interface IUserRepository
{
    Task<List<User>> GetAllAsync(int page, int pageSize);
    Task<User?> GetByIdAsync(int id);
    Task<int> CountAsync();
    Task AddAsync(User user);
    void Update(User user);
    void Remove(User user);
    Task SaveChangesAsync();
}