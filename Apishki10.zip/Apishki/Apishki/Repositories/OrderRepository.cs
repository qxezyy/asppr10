﻿using Apishki.Models;
using Microsoft.EntityFrameworkCore;
namespace Apishki.Repositories;

public class OrderRepository : IOrderRepository
{
    private readonly Db33Context _context;
    public OrderRepository(Db33Context context) => _context = context;

    public async Task<List<Order>> GetAllAsync(int page, int pageSize)
        => await _context.Orders
            .Include(o => o.Uuser)
            .OrderBy(o => o.IdOrder)
            .Skip((page - 1) * pageSize).Take(pageSize)
            .ToListAsync();

    public async Task<Order?> GetByIdAsync(int id)
        => await _context.Orders
            .Include(o => o.Uuser)
            .FirstOrDefaultAsync(o => o.IdOrder == id);

    public async Task<int> CountAsync() => await _context.Orders.CountAsync();
    public async Task AddAsync(Order o) => await _context.Orders.AddAsync(o);
    public void Update(Order o) => _context.Orders.Update(o);
    public void Remove(Order o) => _context.Orders.Remove(o);
    public async Task SaveChangesAsync() => await _context.SaveChangesAsync();
}