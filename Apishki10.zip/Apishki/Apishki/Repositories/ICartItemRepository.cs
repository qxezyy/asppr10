﻿using Apishki.Models;
namespace Apishki.Repositories;

public interface ICartItemRepository
{
    Task<List<CartItem>> GetAllAsync(int page, int pageSize);
    Task<CartItem?> GetByIdAsync(int id);
    Task<int> CountAsync();
    Task AddAsync(CartItem item);
    void Update(CartItem item);
    void Remove(CartItem item);
    Task SaveChangesAsync();
}